Getting help
------------

.. note::
   Please see `Manual:Pywikibot/Communication <https://www.mediawiki.org/w/index.php?title=Manual%3APywikibot%2FCommunication>`_
