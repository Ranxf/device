===============
wikistats_tests
===============
    Tests in ``tests.wikistats_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.wikistats_tests.WikiStatsTestCase
        :members:

