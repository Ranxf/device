===============
namespace_tests
===============
    Tests in ``tests.namespace_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.namespace_tests.TestNamespaceObject
        :members:

