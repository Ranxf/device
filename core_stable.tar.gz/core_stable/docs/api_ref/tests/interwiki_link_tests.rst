====================
interwiki_link_tests
====================
    Tests in ``tests.interwiki_link_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.interwiki_link_tests.TestInterwikiLinksToNonLocalSites
        :members:
    .. autoclass:: tests.interwiki_link_tests.TestPartiallyQualifiedLinkDifferentCodeParser
        :members:

