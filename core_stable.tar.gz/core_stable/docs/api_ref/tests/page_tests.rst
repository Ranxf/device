==========
page_tests
==========
    Tests in ``tests.page_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.page_tests.TestCategoryObject
        :members:
    .. autoclass:: tests.page_tests.TestPageObject
        :members:
    .. autoclass:: tests.page_tests.TestPageObjectEnglish
        :members:
    .. autoclass:: tests.page_tests.TestPageRedirects
        :members:
    .. autoclass:: tests.page_tests.TestPageUserAction
        :members:

