===================
wikidataquery_tests
===================
    Tests in ``tests.wikidataquery_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.wikidataquery_tests.TestApiFunctions
        :members:
    .. autoclass:: tests.wikidataquery_tests.TestApiSlowFunctions
        :members:

