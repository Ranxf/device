==========
http_tests
==========
    Tests in ``tests.http_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.http_tests.DefaultUserAgentTestCase
        :members:
    .. autoclass:: tests.http_tests.HttpTestCase
        :members:
    .. autoclass:: tests.http_tests.ThreadedHttpTestCase
        :members:
    .. autoclass:: tests.http_tests.UserAgentTestCase
        :members:

