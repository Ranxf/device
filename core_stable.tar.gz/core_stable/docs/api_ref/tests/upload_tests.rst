============
upload_tests
============
    Tests in ``tests.upload_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.upload_tests.TestUpload
        :members:

