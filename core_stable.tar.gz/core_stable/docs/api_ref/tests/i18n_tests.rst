==========
i18n_tests
==========
    Tests in ``tests.i18n_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.i18n_tests.TestTWNTranslate
        :members:
    .. autoclass:: tests.i18n_tests.TestTWTranslate
        :members:
    .. autoclass:: tests.i18n_tests.TestTranslate
        :members:

