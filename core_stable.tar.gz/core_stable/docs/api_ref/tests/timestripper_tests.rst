==================
timestripper_tests
==================
    Tests in ``tests.timestripper_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.timestripper_tests.TestTimeStripperWithDigitsAsMonths
        :members:
    .. autoclass:: tests.timestripper_tests.TestTimeStripperWithNoDigitsAsMonths
        :members:

