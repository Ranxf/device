compat Package
==============

:mod:`compat` Package
---------------------

.. automodule:: pywikibot.compat
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`catlib` Module
--------------------

.. automodule:: pywikibot.compat.catlib
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`query` Module
-------------------

.. automodule:: pywikibot.compat.query
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`userlib` Module
---------------------

.. automodule:: pywikibot.compat.userlib
    :members:
    :undoc-members:
    :show-inheritance:

