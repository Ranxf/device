data Package
============

:mod:`data` Package
-------------------

.. automodule:: pywikibot.data
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`api` Module
-----------------

.. automodule:: pywikibot.data.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wikidataquery` Module
---------------------------

.. automodule:: pywikibot.data.wikidataquery
    :members:
    :undoc-members:
    :show-inheritance:

