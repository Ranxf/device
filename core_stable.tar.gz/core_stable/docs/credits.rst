Credits
=======

pywikibot
---------
.. include:: ../CREDITS
   :literal:

documentation
-------------
The documentation was initially maintained on mediawiki.org. The contributors
of the various pages are listed below:

(...to do...)
