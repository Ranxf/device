# -*- coding: utf-8 -*-
"""
This is a fake __init__.py to help pkgutil find the i18n data. There
is no actual python code in this package.
"""
